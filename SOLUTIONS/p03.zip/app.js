let functions = require('./3.LoadData');

result.sort = functions.sort;
result.filter = functions.filter;
