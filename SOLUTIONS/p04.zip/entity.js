class Entity {
    constructor(name){
        if (new.target === Entity) {
            throw new TypeError("Cannot instance abstract class")
        }
        this.name = name;
    }
}

module.exports = Entity;