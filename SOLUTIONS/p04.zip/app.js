result.Entity = require('./entity');
result.Person = require('./person');
result.Dog = require('./dog');
result.Student = require('./student');