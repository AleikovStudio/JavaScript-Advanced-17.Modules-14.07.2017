function mapSort(map, sortFn) {
    if(sortFn === undefined){
        return new Map([...map].sort());

    }
    return new Map([...map].sort(sortFn));
}

module.exports = mapSort;